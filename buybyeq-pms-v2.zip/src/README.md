# PMS (Property Management System)

This is a standalone Property Management System that can run as an independent application or be embedded within a larger application.

## Features

- **Dual Mode Operation**: Can run standalone or embedded
- **Full Router Instance**: Complete routing setup with authentication
- **Theme Support**: Dark/Light theme with context providers
- **Modular Architecture**: Self-contained with all dependencies

## Usage

### As a Standalone App

The PMS can be run as a completely independent application:

1. Set up a separate project with Vite/CRA
2. Point the entry to `src/pms/main.jsx`
3. The app will render with its own router at the root level

```jsx
// In your index.html, ensure you have a root div
<div id="root"></div>

// main.jsx will auto-initialize when imported as entry point
```

### As an Embedded Module

The PMS can be embedded within another React application:

```jsx
import { PMSRouter, PMSAppWithProviders } from './pms/main';
import { BrowserRouter } from 'react-router-dom';

// Option 1: Use PMSRouter (includes BrowserRouter with /pms basename)
function App() {
  return <PMSRouter />;
}

// Option 2: Use PMSAppWithProviders within your own router
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/pms/*" element={<PMSAppWithProviders />} />
        {/* other routes */}
      </Routes>
    </BrowserRouter>
  );
}
```

## Directory Structure

```
pms/
├── api/              # API configuration and axios setup
├── assets/           # Static assets (images, icons, helpers)
├── components/       # Reusable UI components
├── constants/        # App constants (theme, currency, API keys)
├── context/          # React contexts (Theme, Sidebar, Tab)
├── layout/           # Layout components (BaseLayout)
├── screens/          # Page components organized by feature
│   ├── bookings-and-status/
│   ├── dashboard/
│   ├── error/
│   ├── guests/
│   ├── loginsignup/
│   ├── maintenance/
│   ├── reception/
│   ├── reports/
│   ├── reservations/
│   └── settings/
├── App.jsx           # Main PMS application component with routes
├── App.scss          # PMS-specific styles
├── main.jsx          # Entry point with router setup
├── package.json      # Sub-repository package definition
└── README.md         # This file
```

## Authentication

The PMS uses session-based authentication:
- Login status stored in `sessionStorage.ispmsuser`
- User data stored in `sessionStorage.userData`
- Unauthenticated users redirected to `/login`

## Routes

All routes are prefixed with the app's basename. Main routes include:

- `/` - Dashboard
- `/login` - Login page
- `/property/*` - Property management
- `/security/*` - User roles and permissions
- `/reservations/*` - Booking and availability
- `/reception/*` - Reception desk operations
- `/bookings/*` - Booking status views
- `/reports/*` - Various reports
- `/settings/*` - Configuration and settings

## Configuration

No bundler configuration is included in this directory. When linking this as a separate app:

1. Create a Vite or CRA project
2. Install peer dependencies
3. Point entry to `main.jsx`
4. Configure build tools as needed

Example `vite.config.js`:
```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  root: './src/pms',
  build: {
    outDir: '../../dist/pms'
  }
})
```

## Dependencies

See `package.json` for peer dependencies. The PMS requires:
- React 18+
- React Router DOM 6+
- React Icons
- Axios

Additional dependencies are used for UI components, date handling, and charts.

## Environment variables

Needs `VITE_PMS_API_URL` to be defined.

## Notes

- This module is designed to maintain compatibility with the parent application
- All internal routes are relative to the configured basename
- Theme and sidebar state are managed via React Context
- The module can be extracted to a separate repository if needed
