# PMS Standalone Configuration Examples

This directory contains example configurations for running PMS as a standalone application.

## Vite Configuration Example

Create a `vite.config.js` at the root of your standalone project:

```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  
  // Point to PMS directory
  root: './src/pms',
  
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src/pms'),
    },
  },
  
  // Build configuration
  build: {
    outDir: '../../dist/pms',
    emptyOutDir: true,
    sourcemap: true,
  },
  
  // Dev server configuration
  server: {
    port: 3000,
    open: true,
  },
})
```

## Create React App Configuration

For CRA, you would need to eject or use CRACO:

```javascript
// craco.config.js
const path = require('path');

module.exports = {
  webpack: {
    alias: {
      '@': path.resolve(__dirname, 'src/pms'),
    },
  },
  jest: {
    configure: {
      roots: ['<rootDir>/src/pms'],
    },
  },
};
```

## HTML Entry Point

Create an `index.html` at your project root (or in public/ for CRA):

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/logo.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PMS - Property Management System</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/pms/main.jsx"></script>
  </body>
</html>
```

## Package.json for Standalone

```json
{
  "name": "pms-standalone",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.22.3",
    "react-icons": "^5.3.0",
    "axios": "^1.6.8",
    "react-date-range": "^2.0.0-alpha.4",
    "react-datepicker": "^8.0.0",
    "react-modal": "^3.16.1",
    "recharts": "^2.1.9",
    "react-circular-progressbar": "^2.0.4",
    "react-countup": "^6.4.2",
    "date-fns": "^3.1.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.2.1",
    "vite": "^5.0.0",
    "sass": "^1.89.0"
  }
}
```

## Project Structure

```
pms-standalone/
├── public/
│   └── logo.svg
├── src/
│   └── pms/           # Clone or symlink the entire pms directory here
│       ├── api/
│       ├── components/
│       ├── ...
│       └── main.jsx
├── index.html
├── package.json
├── vite.config.js     # or craco.config.js for CRA
└── .gitignore
```

## Setup Steps

1. Create a new directory for standalone PMS:
   ```bash
   mkdir pms-standalone
   cd pms-standalone
   ```

2. Initialize npm and install dependencies:
   ```bash
   npm init -y
   npm install react react-dom react-router-dom react-icons axios # ... other deps
   npm install -D vite @vitejs/plugin-react sass
   ```

3. Copy or link the PMS directory:
   ```bash
   # Option A: Copy
   cp -r /path/to/frontend-combined/src/pms ./src/
   
   # Option B: Git submodule (if PMS is its own repo)
   git submodule add <pms-repo-url> src/pms
   
   # Option C: Symlink (development)
   ln -s /path/to/frontend-combined/src/pms ./src/pms
   ```

4. Create configuration files (vite.config.js, index.html)

5. Run the development server:
   ```bash
   npm run dev
   ```

## Notes

- Ensure all peer dependencies are installed
- The PMS uses SCSS, so make sure your bundler supports it
- Update API endpoints in `src/pms/api/axios.js` if needed
- Configure authentication flow based on your backend
