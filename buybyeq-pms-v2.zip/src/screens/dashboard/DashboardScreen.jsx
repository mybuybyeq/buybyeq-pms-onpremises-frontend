import { useState, useEffect } from "react";
import { AreaCards, AreaCharts, AreaTop } from "../../components";
import DashboardStats from "../../components/dashboard/areaCards/DashboardStats";
import axios from "../../api/axios";

const Dashboard = () => {
  const fetchDashboardData = async (propertyId) => {
    try {
      const response = await axios.get(`pms/dashboard`, {
        params: {
          property_id: propertyId,
          current_date: new Date().toISOString().split("T")[0],
        },
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      throw error;
    }
  };

  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        // Get property ID from session storage
        const userData = JSON.parse(sessionStorage.getItem("userData"));
        const propertyId = userData?.businessEntityId;

        if (!propertyId) {
          setError("No property ID found in session");
          setLoading(false);
          return;
        }

        const data = await fetchDashboardData(propertyId);
        // Ensure we have data for all 6 months, filling in zeros for missing months
        const now = new Date();
        const months = [];
        for (let i = 5; i >= 0; i--) {
          const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
          months.push({
            month: date.toLocaleString("default", { month: "short" }),
            ym: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`,
          });
        }

        const monthlyRevenue = months.map((m) => {
          const found = data.monthlyRevenue.find((item) => item.ym === m.ym);
          return found || { ...m, revenue: 0 };
        });

        setDashboardData({
          ...data,
          monthlyRevenue,
        });
      } catch (err) {
        setError(err.message || "Failed to load dashboard data");
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  if (loading)
    return (
      <div className="loadingg">
        <div className="loading-spinnehr">Loading dashboard...</div>
      </div>
    );
  if (error) return <div className="error-message">Error loading dashboard: {error}</div>;
  if (!dashboardData) return <div className="no-data">No data available</div>;

  return (
    <div className="content-area">
      <DashboardStats stats={dashboardData.stats} />
      <div style={{ paddingTop: "20px" }}>
        <AreaCharts
          monthlyRevenue={dashboardData.monthlyRevenue}
          topRooms={dashboardData.topRooms}
          currentRevenue={dashboardData.stats.totalRevenue.amount}
          revenueComparison={dashboardData.stats.totalRevenue.comparison}
        />
      </div>
    </div>
  );
};

export default Dashboard;
