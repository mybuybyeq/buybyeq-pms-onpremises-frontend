import React, { useEffect, useState } from "react";
import { FiX, FiUsers, FiSave } from "react-icons/fi";
import axios from "../../../api/axios";
import { format, differenceInCalendarDays } from "date-fns";
import { BASE_CURRENCY } from "../../../constants/currency";

const GroupBookingModal = ({
  open,
  onClose,
  property, // selectedProperty object
  dateRange, // { startDate, endDate }
  roomTypes, // from parent
  mealPlans, // from parent
  extraServices, // from parent (optional use later)
  showSnackbar, // parent's snackbar function
}) => {
  const [loadingRooms, setLoadingRooms] = useState(false);
  const [availableRooms, setAvailableRooms] = useState([]);
  const [selectedRoomIds, setSelectedRoomIds] = useState([]);

  const [groupBookingInfo, setGroupBookingInfo] = useState({
    useBasePrice: true,
    mealPlan: null,
    adults: 2,
    children: 0,
    infants: 0,
  });

  const [guestInfo, setGuestInfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    nationality: "",
    idType: "",
    idNumber: "",
    notes: "",
    company: "",
    gst: "",
  });

  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState("Cash");

  const nights = (() => {
    if (!dateRange?.startDate || !dateRange?.endDate) return 1;
    const diff = differenceInCalendarDays(dateRange.endDate, dateRange.startDate);
    return diff <= 0 ? 1 : diff;
  })();

  // Helpers (copied from your logic style) :contentReference[oaicite:0]{index=0}
  const getDefaultMealPlanForRoomType = (roomTypeId) => {
    const applicableMealPlans = mealPlans.filter((mp) => mp.room_type_id === null || mp.room_type_id === roomTypeId);
    if (applicableMealPlans.length === 0) return null;
    const roomTypeSpecific = applicableMealPlans.find((mp) => mp.room_type_id === roomTypeId);
    return roomTypeSpecific || applicableMealPlans[0];
  };

  const calculatePriceForRoom = (roomType, bookingInfo, nightsCount) => {
    if (!roomType) return 0;

    const mealPlan = bookingInfo.mealPlan
      ? mealPlans.find((mp) => mp.id === Number(bookingInfo.mealPlan))
      : getDefaultMealPlanForRoomType(roomType.id);

    let totalPrice = 0;

    if (bookingInfo.useBasePrice) {
      const basePrice = mealPlan?.base_price || roomType.base_price || 0;
      totalPrice = basePrice * nightsCount;
    } else if (mealPlan) {
      const adultPrice = parseFloat(mealPlan.adult_price || mealPlan.base_price || roomType.base_price || 0);
      const childPrice = parseFloat(mealPlan.child_price || mealPlan.base_price / 2 || roomType.base_price / 2 || 0);
      const infantPrice = parseFloat(mealPlan.infant_price || 0);

      totalPrice =
        (adultPrice * bookingInfo.adults + childPrice * bookingInfo.children + infantPrice * bookingInfo.infants) *
        nightsCount;
    } else {
      const basePrice = roomType.base_price || 0;
      totalPrice = basePrice * bookingInfo.adults * nightsCount;
    }

    return totalPrice;
  };

  const estimatedTotal = selectedRoomIds.reduce((sum, roomId) => {
    const room = availableRooms.find((r) => r.id === roomId);
    if (!room) return sum;
    const roomType = roomTypes.find((rt) => rt.id === room.room_type_id);
    return sum + calculatePriceForRoom(roomType, groupBookingInfo, nights);
  }, 0);

  // Fetch vacant rooms for the date range when modal opens :contentReference[oaicite:1]{index=1}
  useEffect(() => {
    if (!open || !property || !dateRange?.startDate || !dateRange?.endDate) return;

    const fetchVacantRooms = async () => {
      try {
        setLoadingRooms(true);
        setSelectedRoomIds([]);

        const start = format(dateRange.startDate, "yyyy-MM-dd");
        const end = format(dateRange.endDate, "yyyy-MM-dd");

        const resp = await axios.get(`/pms/rooms/getVacantRooms/${null}/${property.business_entity_id}`, {
          params: {
            start_date: start,
            end_date: end,
          },
        });

        setAvailableRooms(Array.isArray(resp.data) ? resp.data : []);
      } catch (err) {
        console.error("Error loading vacant rooms for group booking:", err);
        showSnackbar && showSnackbar("Failed to load vacant rooms", "error");
        setAvailableRooms([]);
      } finally {
        setLoadingRooms(false);
      }
    };

    fetchVacantRooms();
  }, [open, property, dateRange, showSnackbar]);

  const toggleRoomSelection = (roomId) => {
    setSelectedRoomIds((prev) => (prev.includes(roomId) ? prev.filter((id) => id !== roomId) : [...prev, roomId]));
  };

  const handleClose = () => {
    onClose && onClose();
  };

  const handleSaveGroupBooking = () => {
    if (!selectedRoomIds.length) {
      showSnackbar && showSnackbar("Please select at least one room", "error");
      return;
    }
    if (!guestInfo.phone) {
      showSnackbar && showSnackbar("Guest phone is required", "error");
      return;
    }

    const selectedRooms = availableRooms.filter((room) => selectedRoomIds.includes(room.id));

    const payload = {
      property_id: property.business_entity_id,
      start_date: format(dateRange.startDate, "yyyy-MM-dd"),
      end_date: format(dateRange.endDate, "yyyy-MM-dd"),
      nights,
      guest: guestInfo,
      booking: {
        ...groupBookingInfo,
        total_estimated_amount: estimatedTotal,
      },
      rooms: selectedRooms.map((room) => ({
        room_id: room.id,
        room_type_id: room.room_type_id,
        charge_code: room.charge_code,
        unit_number: room.unit_number,
        max_pax: room.max_pax,
        floor: room.floor,
      })),
      payment: {
        amount: paymentAmount,
        method: paymentMethod,
      },
    };

    // 🔴 No backend call for now – just log it
    console.log("GROUP BOOKING PAYLOAD (TODO: send to backend API)", payload);

    showSnackbar && showSnackbar("Group booking payload prepared. Connect backend API to save.", "success");

    handleClose();
  };

  if (!open) return null;

  return (
    <div className="modal-overlay">
      <div className="modal booking-modal group-booking-modal">
        <div className="modal-header">
          <h3>
            <FiUsers style={{ marginRight: 8 }} />
            Group Room Booking
          </h3>
          <button onClick={handleClose}>
            <FiX />
          </button>
        </div>

        <div className="modal-content group-booking-content">
          <div className="group-columns">
            {/* LEFT: Rooms list */}
            <div className="group-left">
              <div className="booking-dates">
                <div className="date-range-display">
                  <span>Check-In: {format(dateRange.startDate, "MMM d, yyyy")}</span>
                  <span style={{ marginLeft: 12 }}>Checkout: {format(dateRange.endDate, "MMM d, yyyy")}</span>
                  <span style={{ marginLeft: 12 }}>
                    ({nights} night{nights > 1 ? "s" : ""})
                  </span>
                </div>
              </div>

              <div className="group-rooms-list">
                {loadingRooms ? (
                  <div style={{ padding: 12 }}>Loading available rooms...</div>
                ) : availableRooms.length === 0 ? (
                  <div style={{ padding: 12 }}>No vacant rooms for selected date range.</div>
                ) : (
                  <table className="group-rooms-table">
                    <thead>
                      <tr>
                        <th></th>
                        <th>Room</th>
                        <th>Type</th>
                        <th>Floor</th>
                        <th>Max Pax</th>
                      </tr>
                    </thead>
                    <tbody>
                      {availableRooms.map((room) => {
                        const rt = roomTypes.find((t) => t.id === room.room_type_id);
                        return (
                          <tr key={room.id}>
                            <td>
                              <input
                                type="checkbox"
                                checked={selectedRoomIds.includes(room.id)}
                                onChange={() => toggleRoomSelection(room.id)}
                              />
                            </td>
                            <td>
                              {room.charge_code} {room.unit_number}
                            </td>
                            <td>{rt?.room_type || "-"}</td>
                            <td>{room.floor ?? "-"}</td>
                            <td>{room.max_pax ?? rt?.max_occupancy ?? "-"}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>

            {/* RIGHT: Common booking config + guest + payment */}
            <div className="group-right">
              {/* Pricing mode and meal plan */}
              <div
                style={{
                  marginBottom: 16,
                  padding: 12,
                  borderRadius: 8,
                  border: "1px solid #ffcc80",
                }}
              >
                <label style={{ fontWeight: 600, display: "block" }}>Pricing Mode</label>
                <div style={{ marginTop: 8 }}>
                  <label style={{ marginRight: 16 }}>
                    <input
                      type="radio"
                      name="useBasePrice"
                      checked={groupBookingInfo.useBasePrice === true}
                      onChange={() =>
                        setGroupBookingInfo((p) => ({
                          ...p,
                          useBasePrice: true,
                        }))
                      }
                    />{" "}
                    Base Price
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="useBasePrice"
                      checked={groupBookingInfo.useBasePrice === false}
                      onChange={() =>
                        setGroupBookingInfo((p) => ({
                          ...p,
                          useBasePrice: false,
                        }))
                      }
                    />{" "}
                    Per Person
                  </label>
                </div>

                <div
                  style={{
                    fontSize: "0.8rem",
                    color: "#666",
                    marginTop: 8,
                  }}
                >
                  This setting will be applied to all selected rooms.
                </div>
              </div>

              <div className="form-group">
                <label>Meal Plan</label>
                <select
                  value={groupBookingInfo.mealPlan || getDefaultMealPlanForRoomType(roomTypes[0]?.id ?? null)?.id || ""}
                  onChange={(e) =>
                    setGroupBookingInfo((p) => ({
                      ...p,
                      mealPlan: e.target.value,
                    }))
                  }
                >
                  <option value="">Select meal plan</option>
                  {mealPlans.map((mp) => (
                    <option key={mp.id} value={mp.id}>
                      {mp.name} – {BASE_CURRENCY}
                      {(mp.base_price || mp.adult_price || 0).toLocaleString()}
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Adults</label>
                  <input
                    type="number"
                    min={1}
                    value={groupBookingInfo.adults}
                    onChange={(e) =>
                      setGroupBookingInfo((p) => ({
                        ...p,
                        adults: Math.max(1, parseInt(e.target.value) || 1),
                      }))
                    }
                  />
                </div>
                <div className="form-group">
                  <label>Children</label>
                  <input
                    type="number"
                    min={0}
                    value={groupBookingInfo.children}
                    onChange={(e) =>
                      setGroupBookingInfo((p) => ({
                        ...p,
                        children: Math.max(0, parseInt(e.target.value) || 0),
                      }))
                    }
                  />
                </div>
                <div className="form-group">
                  <label>Infants</label>
                  <input
                    type="number"
                    min={0}
                    value={groupBookingInfo.infants}
                    onChange={(e) =>
                      setGroupBookingInfo((p) => ({
                        ...p,
                        infants: Math.max(0, parseInt(e.target.value) || 0),
                      }))
                    }
                  />
                </div>
              </div>

              {/* Guest info (one guest for all rooms) */}
              <div style={{ marginTop: 16 }}>
                <h4>Guest Details (Single Guest)</h4>
                <div className="form-row">
                  <div className="form-group">
                    <label>First Name</label>
                    <input
                      type="text"
                      value={guestInfo.firstName}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          firstName: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="form-group">
                    <label>Last Name</label>
                    <input
                      type="text"
                      value={guestInfo.lastName}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          lastName: e.target.value,
                        }))
                      }
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Phone *</label>
                    <input
                      type="text"
                      value={guestInfo.phone}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          phone: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      value={guestInfo.email}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          email: e.target.value,
                        }))
                      }
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Country</label>
                    <input
                      type="text"
                      value={guestInfo.nationality}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          nationality: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="form-group">
                    <label>ID Type</label>
                    <input
                      type="text"
                      value={guestInfo.idType}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          idType: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="form-group">
                    <label>ID Number</label>
                    <input
                      type="text"
                      value={guestInfo.idNumber}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          idNumber: e.target.value,
                        }))
                      }
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Company</label>
                    <input
                      type="text"
                      value={guestInfo.company}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          company: e.target.value,
                        }))
                      }
                    />
                  </div>
                  <div className="form-group">
                    <label>GST</label>
                    <input
                      type="text"
                      value={guestInfo.gst}
                      onChange={(e) =>
                        setGuestInfo((p) => ({
                          ...p,
                          gst: e.target.value,
                        }))
                      }
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>Notes</label>
                  <textarea
                    rows={2}
                    value={guestInfo.notes}
                    onChange={(e) =>
                      setGuestInfo((p) => ({
                        ...p,
                        notes: e.target.value,
                      }))
                    }
                  />
                </div>
              </div>

              {/* Payment section */}
              <div style={{ marginTop: 16 }}>
                <h4>Payment</h4>
                <div className="price-summary">
                  <div className="price-line">
                    <span>Rooms selected:</span>
                    <span>{selectedRoomIds.length}</span>
                  </div>
                  <div className="price-line">
                    <span>Estimated Total:</span>
                    <span>
                      {BASE_CURRENCY}
                      {estimatedTotal.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="form-row" style={{ marginTop: 8 }}>
                  <div className="form-group">
                    <label>Payment Amount (Advance)</label>
                    <input
                      type="number"
                      min={0}
                      value={paymentAmount}
                      onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                    />
                  </div>
                  <div className="form-group">
                    <label>Payment Method</label>
                    <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                      <option value="Cash">Cash</option>
                      <option value="Card">Card</option>
                      <option value="UPI">UPI</option>
                      <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                  </div>
                </div>
                <div style={{ fontSize: "0.8rem", color: "#666" }}>
                  * For now this is only UI. When your group booking API is ready, send this payload from here.
                </div>
              </div>
            </div>
          </div>

          <div className="modal-actions" style={{ marginTop: 16 }}>
            <button className="btn-secondary" onClick={handleClose}>
              Cancel
            </button>
            <button className="btn-primary" onClick={handleSaveGroupBooking} disabled={!selectedRoomIds.length}>
              <FiSave style={{ marginRight: 6 }} />
              Save Group Booking (Prepare Payload)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupBookingModal;
