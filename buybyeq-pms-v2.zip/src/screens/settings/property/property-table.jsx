import { useState, useEffect } from "react";
import axios from "../../../api/axios";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import EmptyState from "../../error/EmptyState";

const TABLE_HEADS = [
  "#",
  "Logo",
  "Business Name",
  "Manager Name",
  "Email",
  "Contact No",
  "Address",
  "GST Number",
  "CGST",
  "SGST",
  "Invoice Prefix",
  "Action",
];

const PropertyTable = () => {
  const [tableData, setTableData] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProperty, setEditingProperty] = useState(null);
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreview, setLogoPreview] = useState(null);
  const [existingLogoUrl, setExistingLogoUrl] = useState(null);
  const [newProperty, setNewProperty] = useState({
    businessName: "",
    Manager: "",
    Email: "",
    contactNo: "",
    Address: "",
    ManagerEmail: "",
    Business_type: "H",
    gstNumber: "", // optional
    cgst: "", // optional
    sgst: "", // optional
    invoice_code: "", // optional
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    const userData = JSON.parse(sessionStorage.getItem("userData"));
    try {
      const response = await axios.get(`businessEntities/getAllBusinessEntities/${userData.Group_ID}`);

      const data = Array.isArray(response.data) ? response.data : [];

      const filteredData = data
        .filter((business) => business.business_type === "H")
        .map((business, index) => ({
          id: business.business_entity_id,
          rowNumber: index + 1,
          businessName: business.business_name,
          Manager: business.name,
          Email: business.email,
          contactNo: business.contact_no,
          Address: business.address,
          ManagerEmail: business.manager_email || business.email,
          logoUrl: business.logo_url || null,
          gstNumber: business.gst_number || "",
          cgst: business.cgst != null ? String(business.cgst) : "",
          sgst: business.sgst != null ? String(business.sgst) : "",
          invoice_code: business.invoice_code || "",
        }));

      setTableData(filteredData);
    } catch (error) {
      showSnackbar("Error fetching properties", "error");
      console.error("Error fetching data:", error);
    }
  };

  const uploadLogoAndGetUrl = async () => {
    if (!logoFile) return null;
    const formData = new FormData();
    formData.append("logo", logoFile);
    formData.append("businessEntityId", editingProperty ? editingProperty.id : "");
    try {
      const res = await axios.post("/registration/updateLogo", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      return res.data.fileUrl;
    } catch (error) {
      showSnackbar("Image upload failed", "error");
      console.error("Image upload error:", error);
      return null;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const userData = JSON.parse(sessionStorage.getItem("userData"));

    try {
      let logoUrl = null;

      if (logoFile) {
        logoUrl = await uploadLogoAndGetUrl();
        if (!logoUrl) return;
      } else if (editingProperty && existingLogoUrl) {
        logoUrl = existingLogoUrl;
      }

      const payload = {
        businessName: newProperty.businessName,
        Manager: newProperty.Manager,
        Email: newProperty.Email,
        contactNo: newProperty.contactNo,
        Address: newProperty.Address,
        ManagerEmail: newProperty.ManagerEmail,
        Business_type: newProperty.Business_type,
        Group_ID: userData.Group_ID,
      };

      if (logoUrl) payload.logo_url = logoUrl;

      // Optional fields
      if (newProperty.gstNumber && newProperty.gstNumber.trim() !== "") {
        payload.GstNumber = newProperty.gstNumber.trim();
      }
      if (newProperty.cgst !== "" && newProperty.cgst != null) {
        const cgstNumber = Number(newProperty.cgst);
        if (!Number.isNaN(cgstNumber)) payload.cgst = cgstNumber;
      }
      if (newProperty.sgst !== "" && newProperty.sgst != null) {
        const sgstNumber = Number(newProperty.sgst);
        if (!Number.isNaN(sgstNumber)) payload.sgst = sgstNumber;
      }
      if (newProperty.invoice_code && newProperty.invoice_code.trim() !== "") {
        payload.invoice_code = newProperty.invoice_code.trim();
      }

      if (editingProperty) {
        await axios.put(`businessEntities/editBusinessEntity/${editingProperty.id}`, payload);
        showSnackbar("Property updated successfully", "success");
      } else {
        await axios.post("businessEntities/addBusinessEntity", payload);
        showSnackbar("Property added successfully", "success");
      }

      fetchProperties();
      handleModalClose();
    } catch (error) {
      const errorMsg = error.response?.data?.error || "Operation failed";
      showSnackbar(errorMsg, "error");
      console.error("Error:", error);
    }
  };

  const handleEdit = (property) => {
    setEditingProperty(property);
    setNewProperty({
      businessName: property.businessName,
      Manager: property.Manager,
      Email: property.Email,
      contactNo: property.contactNo,
      Address: property.Address,
      ManagerEmail: property.ManagerEmail,
      Business_type: property.business_type || "H",
      gstNumber: property.gstNumber || "",
      cgst: property.cgst || "",
      sgst: property.sgst || "",
      invoice_code: property.invoice_code || "",
    });
    setLogoFile(null);

    if (property.logoUrl) {
      const fullLogoUrl = property.logoUrl.startsWith("http")
        ? property.logoUrl
        : `${axios.defaults.baseURL}/${property.logoUrl}`;
      setLogoPreview(fullLogoUrl);
      setExistingLogoUrl(property.logoUrl);
    } else {
      setLogoPreview(null);
      setExistingLogoUrl(null);
    }

    setIsModalOpen(true);
  };

  const handleDelete = async (property) => {
    const confirmDelete = window.confirm(`Are you sure you want to delete ${property.businessName}?`);
    if (confirmDelete) {
      try {
        await axios.delete(`businessEntities/deleteBusinessEntity/${property.id}`);
        showSnackbar("Property deleted successfully", "success");
        fetchProperties();
      } catch (error) {
        showSnackbar("Error deleting property", "error");
        console.error("Error deleting property:", error);
      }
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewProperty((prev) => ({ ...prev, [name]: value }));
  };

  const showSnackbar = (message, severity) => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar((prev) => ({ ...prev, open: false }));
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setEditingProperty(null);
    setLogoFile(null);
    setLogoPreview(null);
    setNewProperty({
      businessName: "",
      Manager: "",
      Email: "",
      contactNo: "",
      Address: "",
      ManagerEmail: "",
      Business_type: "H",
      gstNumber: "",
      cgst: "",
      sgst: "",
      invoice_code: "",
    });
  };

  return (
    <section className="content-area-table">
      <div className="data-table-info">
        <h4 className="data-table-title">Properties Overview</h4>
        {tableData.length > 0 && (
          <button className="add-btn" onClick={() => setIsModalOpen(true)}>
            + Add Property
          </button>
        )}
      </div>

      {tableData.length > 0 ? (
        <div className="data-table-diagram">
          <table>
            <thead>
              <tr>
                {TABLE_HEADS.map((th, index) => (
                  <th key={index}>{th}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableData.map((dataItem) => (
                <tr key={dataItem.id}>
                  <td>{dataItem.rowNumber}</td>
                  <td>
                    <img
                      src={
                        dataItem.logoUrl ? `${axios.defaults.baseURL}/${dataItem.logoUrl}` : "/images/default-logo.png"
                      }
                      alt="logo"
                      style={{ width: "40px", height: "40px", borderRadius: "4px", objectFit: "cover" }}
                    />
                  </td>
                  <td>{dataItem.businessName}</td>
                  <td>{dataItem.Manager}</td>
                  <td>{dataItem.Email}</td>
                  <td>{dataItem.contactNo}</td>
                  <td>{dataItem.Address}</td>
                  <td>{dataItem.gstNumber || "-"}</td>
                  <td>{dataItem.cgst !== "" ? dataItem.cgst : "-"}</td>
                  <td>{dataItem.sgst !== "" ? dataItem.sgst : "-"}</td>
                  <td>{dataItem.invoice_code || "-"}</td>
                  <td className="dt-cell-action" style={{ textAlign: "center" }}>
                    <div style={{ display: "flex", gap: "8px", justifyContent: "center" }}>
                      <button onClick={() => handleEdit(dataItem)} className="edit-btn" title="Edit">
                        Edit
                      </button>
                      <button onClick={() => handleDelete(dataItem)} className="delete-btn" title="Delete">
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState
          title=""
          subtitle="No properties were found for this business."
          description="There are currently no properties available. You can add a new property to get started."
          actionButton={
            <button className="add-btn" onClick={() => setIsModalOpen(true)}>
              + Add Property
            </button>
          }
        />
      )}

      {isModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>{editingProperty ? "Edit Property" : "Add New Property"}</h3>
              <button className="close-btn" onClick={handleModalClose}>
                &times;
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              {[
                { label: "Property Name", name: "businessName" },
                { label: "Manager Name", name: "Manager" },
                { label: "Manager Email", name: "ManagerEmail", type: "email" },
                { label: "Property Email", name: "Email", type: "email" },
                { label: "Contact No", name: "contactNo" },
                { label: "Address", name: "Address" },
              ].map(({ label, name, type = "text" }) => (
                <div className="form-group" key={name}>
                  <label>{label}:</label>
                  <input type={type} name={name} value={newProperty[name]} onChange={handleInputChange} required />
                </div>
              ))}

              <div className="form-group">
                <label>GST Number:</label>
                <input
                  type="text"
                  name="gstNumber"
                  value={newProperty.gstNumber}
                  onChange={handleInputChange}
                  placeholder="Optional"
                />
              </div>

              <div className="form-group">
                <label>CGST (%):</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  name="cgst"
                  value={newProperty.cgst}
                  onChange={handleInputChange}
                  placeholder="Optional"
                />
              </div>

              <div className="form-group">
                <label>SGST (%):</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  name="sgst"
                  value={newProperty.sgst}
                  onChange={handleInputChange}
                  placeholder="Optional"
                />
              </div>

              <div className="form-group">
                <label>Invoice Prefix:</label>
                <input
                  type="text"
                  name="invoice_code"
                  value={newProperty.invoice_code}
                  onChange={handleInputChange}
                  placeholder="e.g. BBQ, INV, JAM..."
                />
              </div>

              <div className="form-group">
                <label>Logo Image:</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files[0];
                    setLogoFile(file);
                    setLogoPreview(file ? URL.createObjectURL(file) : null);
                  }}
                />
                {logoPreview && (
                  <img
                    src={logoPreview}
                    alt="Preview"
                    style={{ width: "80px", height: "80px", marginTop: "8px", objectFit: "cover", borderRadius: "4px" }}
                  />
                )}
              </div>

              <div className="modal-actions">
                <button type="button" className="cancel-btn" onClick={handleModalClose}>
                  Cancel
                </button>
                <button type="submit" className="submit-btn">
                  {editingProperty ? "Update Property" : "Add Property"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity} sx={{ width: "100%" }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </section>
  );
};

export default PropertyTable;
