/**
 * Example Vite Configuration for PMS Standalone
 * 
 * To use this:
 * 1. Copy or symlink the pms directory to a new project
 * 2. Place this file as vite.config.js in the project root
 * 3. Install dependencies from package.json
 * 4. Run: npm run dev
 */

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  
  // If PMS is in src/pms subdirectory, use this:
  // root: './src/pms',
  
  // If PMS is at root level, use this:
  root: '.',
  
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './'),
    },
  },
  
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom', 'react-router-dom'],
          'ui-vendor': ['react-icons', 'recharts', 'react-datepicker'],
        },
      },
    },
  },
  
  server: {
    port: 3000,
    open: true,
    host: true,
  },
  
  preview: {
    port: 4173,
    open: true,
  },
  
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: `@import "./App.scss";`
      }
    }
  }
})
